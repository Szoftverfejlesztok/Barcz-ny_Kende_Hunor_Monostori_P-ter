<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vásárló</title>
    <link rel="stylesheet" href="style3.css">
    <script defer>
        document.addEventListener("DOMContentLoaded", function () {
            const alapanyagok = [
                { id: 1, nev: "Fém", egyseg: "kg" },
                { id: 2, nev: "Fémcső", egyseg: "db" },
                { id: 3, nev: "Fémrúd", egyseg: "m" },
                { id: 4, nev: "Vas", egyseg: "kg" },
                { id: 5, nev: "Vasrúd", egyseg: "m" },
                { id: 6, nev: "Vascső", egyseg: "db" }
            ];

            const tartalomDiv = document.getElementById("tartalom");
            const form = document.createElement("form");
            form.id = "orderForm";

            alapanyagok.forEach(alapanyag => {
                const listItem = document.createElement("div");
                listItem.classList.add("anyag-container");
                listItem.innerHTML = `
                    <label for="anyag-${alapanyag.id}">${alapanyag.nev} (${alapanyag.egyseg}):</label>
                    <select id="anyag-${alapanyag.id}" class="dropdown" data-id="${alapanyag.id}">
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>

                    </select>
                `;
                form.appendChild(listItem);
            });

            const buttonContainer = document.createElement("div");
            buttonContainer.classList.add("button-container");

            const button = document.createElement("button");
            button.type = "button";
            button.textContent = "Megrendelés";
            button.id = "submitOrder";
            buttonContainer.appendChild(button);
            form.appendChild(buttonContainer);

            tartalomDiv.appendChild(form);

            button.addEventListener("click", function () {
                let selectedItems = [];
                let selects = document.querySelectorAll(".dropdown");

                selects.forEach(select => {
                    let amount = select.value;
                    let materialName = select.previousElementSibling.textContent;

                    if (amount > 0) {
                        selectedItems.push(`${materialName} ${amount}`);
                    }
                });

                if (selectedItems.length === 0) {
                    alert("Kérlek válassz ki legalább egy alapanyagot!");
                } else {
                    let orders = JSON.parse(localStorage.getItem("rendelesek"));

                if (!Array.isArray(orders)) {
                    orders = [];
                }
                    orders.push(selectedItems);
                    localStorage.setItem("rendelesek", JSON.stringify(orders));
                    

                    alert("Rendelés rögzítve! Továbbítás az admin oldalra...");
                    window.location.href = "admin.php";
                }
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Üdvözöljük, Vásárló!</h1>
        </div>
        <div id="tartalom" class="tartalom">
            <h1>Elérhető alapanyagok</h1>
        </div>
    </div>
</body>
</html>