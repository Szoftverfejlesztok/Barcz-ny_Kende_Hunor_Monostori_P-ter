<?php
define("DBTTYPE","mysql");
define("DBHOST","localhost");
define("DBNAME","vizsgaremek1");
define("DBCHARSET","utf8");
define("DBUSER","root");
define("DBPASSWORD","");

define("ERRORLOG","./error.log");
?>