<?php
session_start();
require_once("config.php");  // Adatbázis kapcsolati információk

$error = "";
$msg = "";

// Bejelentkezés blokk
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once("dbconnect.php");  // Az adatbázis kapcsolat betöltése

    if (!empty($dbconn)) {
        $adminUsername = $_POST["adminUsername"];
        $adminPassword = $_POST["adminPassword"];

        try {
            // Ha a felhasználónév vagy jelszó üres
            if (empty($adminUsername) || empty($adminPassword)) {
                throw new Exception("Hiányzó felhasználónév vagy jelszó");
            }

            // Először ellenőrizzük, hogy létezik-e már az admin felhasználó
            $sqlAdmin = "SELECT id, felhasznalonev, jelszo FROM admin WHERE felhasznalonev = :username";
            $queryAdmin = $dbconn->prepare($sqlAdmin);
            $queryAdmin->execute(array("username" => $adminUsername));
            $admin = $queryAdmin->fetch(PDO::FETCH_ASSOC);

            // Ha nincs admin felhasználó, akkor létrehozzuk
            if (!$admin) {
                // Admin felhasználó és jelszó feltöltése az adatbázisba (nem hash-elve)
                $sqlInsert = "INSERT INTO admin (felhasznalonev, jelszo) VALUES (:username, :password)";
                $queryInsert = $dbconn->prepare($sqlInsert);
                $queryInsert->bindValue(":username", $adminUsername);
                $queryInsert->bindValue(":password", $adminPassword);  // Jelszó nem hash-elve
                $queryInsert->execute();
                
                $msg = "Admin felhasználó sikeresen létrehozva!";
                // Admin felhasználó létrehozása után most már folytathatjuk a bejelentkezési ellenőrzést
                // Az admin változót frissítjük, hogy a legfrissebb adatokkal dolgozzunk.
                $admin = [
                    "felhasznalonev" => $adminUsername,
                    "jelszo" => $adminPassword // Nem hash-elt jelszó
                ];
            }

            // Bejelentkezési ellenőrzés (jelszó nem hash-elt, közvetlen összehasonlítás)
            if ($admin && $adminPassword == $admin["jelszo"]) {
                // Belépés sikeres
                $_SESSION["admin"] = array(
                    "admin_id" => $admin["id"], // Az id-t is beállítjuk
                    "felhasznalonev" => $admin["felhasznalonev"]
                );

                // Átirányítás a rendszergazda oldalra
                header("Location: Admin.php");
                exit(); // Ne felejtsd el az exit-t!
            } else {
                throw new Exception("Hibás felhasználónév vagy jelszó");
            }
        } catch (Exception $e) {
            $error = "Bejelentkezési hiba: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendszergazda Bejelentkezés</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Rendszergazda Bejelentkezés</h1>
            <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
            <?php if (!empty($msg)) echo "<p style='color: green;'>$msg</p>"; ?>
            <form action="" method="POST">
                <input type="text" name="adminUsername" placeholder="Felhasználónév" required autocomplete="username"><br>
                <br>
                <input type="password" name="adminPassword" placeholder="Jelszó" required autocomplete="current-password"><br>
                <br>
                <button type="submit">Bejelentkezés</button>
            </form>
        </div>
    </div>
</body>
</html>
