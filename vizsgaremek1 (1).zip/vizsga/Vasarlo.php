<?php
require_once("config.php");
$error = "";
$msg = "";
session_start();

// Regisztráció blokk
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["customerUsername"])) {
    require_once("dbconnect.php");

    if (!empty($dbconn)) {
        $username = $_POST["customerUsername"];
        $email = $_POST["customerEmail"];
        $password = $_POST["customerPassword"];

        try {
            if (empty($username) || empty($email) || empty($password)) {
                throw new Exception("Hiányzó felhasználónév, email vagy jelszó");
            }

            // Ellenőrizzük, hogy létezik-e már a felhasználónév
            $sqlCheckUser = "SELECT * FROM vasarlo WHERE felhasznalonev = :username";
            $queryCheckUser = $dbconn->prepare($sqlCheckUser);
            $queryCheckUser->execute(array("username" => $username));

            if ($queryCheckUser->rowCount() > 0) {
                throw new Exception("A felhasználónév már létezik");
            }

            // Jelszó hash-elése
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Felhasználó regisztrálása
            $sql = "INSERT INTO vasarlo (felhasznalonev,  jelszo) VALUES (:username, :password)";
            $query = $dbconn->prepare($sql);
            $query->bindValue(":username", $username);
            $query->bindValue(":password", $hashedPassword);
            $query->execute();

            $msg = "Sikeres regisztráció! Most már bejelentkezhetsz.";

        } catch (Exception $e) {
            $error = "Regisztrációs hiba: " . $e->getMessage();
        }
    }
}

// Bejelentkezés blokk
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["loginUsername"])) {
    require_once("dbconnect.php");

    if (!empty($dbconn)) {
        $username = $_POST["loginUsername"];
        $password = $_POST["loginPassword"];

        try {
            if (empty($username) || empty($password)) {
                throw new Exception("Hiányzó felhasználónév vagy jelszó");
            }

            $sqlLogin = "SELECT vasarlo_id, felhasznalonev, jelszo FROM vasarlo WHERE felhasznalonev = :username";
            $queryLogin = $dbconn->prepare($sqlLogin);
            $queryLogin->execute(array("username" => $username));
            $user = $queryLogin->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user["jelszo"])) {
                $_SESSION["user"] = array(
                    "vasarlo_id" => $user["vasarlo_id"],
                    "felhasznalonev" => $user["felhasznalonev"]
                );

                // Átirányítás a bejelentkezett oldalra
                header("Location: Vasarlo2.php");
                exit();
            } else {
                throw new Exception("Hibás jelszó vagy felhasználónév");
            }
        } catch (Exception $e) {
            $error = "Bejelentkezési hiba: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vásárló Regisztráció/Bejelentkezés</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Vásárló Regisztráció</h1>
            <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
            <?php if (!empty($msg)) echo "<p style='color: green;'>$msg</p>"; ?>
            <form method="POST">
                <input type="text" name="customerUsername" placeholder="Felhasználónév" required>
                <br><br>
                <input type="email" name="customerEmail" placeholder="Email" required>
                <br><br>
                <input type="password" name="customerPassword" placeholder="Jelszó" required>
                <br><br>
                <button type="submit">Regisztráció</button>
            </form>

            <h2>Vagy már van fiókja?</h2>
            <br>
            <form method="POST">
                <input type="text" name="loginUsername" placeholder="Felhasználónév" required>
                <br><br>
                <input type="password" name="loginPassword" placeholder="Jelszó" required>
                <br><br>
                <button type="submit">Bejelentkezés</button>
            </form>
        </div>
    </div>
</body>
</html>
