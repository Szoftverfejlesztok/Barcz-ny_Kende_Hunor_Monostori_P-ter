<?php
require_once("config.php");
$error = "";
$msg = "";
session_start();

// Bejelentkezés blokk
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once("dbconnect.php");

    if (!empty($dbconn)) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        try {
            // Ha a felhasználónév vagy jelszó üres
            if (empty($username) || empty($password)) {
                throw new Exception("Hiányzó felhasználónév vagy jelszó");
            }

            // Lekérdezzük a felhasználót a partner táblából
            $sqlLogin = "SELECT partner_id, felhasznalonev, jelszo FROM partner WHERE felhasznalonev = :username";
            $queryLogin = $dbconn->prepare($sqlLogin);
            $queryLogin->execute(array("username" => $username));
            $user = $queryLogin->fetch(PDO::FETCH_ASSOC);

            // Ha a felhasználó már létezik
            if ($user) {
                if (password_verify($password, $user["jelszo"])) {
                    // Jelszó helyes, belépés
                    $_SESSION["user"] = array(
                        "partner_id" => $user["partner_id"],
                        "felhasznalonev" => $user["felhasznalonev"]
                    );
                    // Átirányítás
                    header("Location: Partner2.php");
                    exit(); // Ne felejtsd el az exit-t!
                } else {
                    throw new Exception("Hibás jelszó");
                }
            } else {
                // Ha nem található ilyen felhasználó, új felhasználó regisztrálása
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);  // Jelszó hash-elése
                $sql = "INSERT INTO partner (felhasznalonev, jelszo) VALUES (:username, :password)";
                $query = $dbconn->prepare($sql);
                $query->bindValue(":username", $username);
                $query->bindValue(":password", $hashedPassword);
                $query->execute();

                $msg = "Új felhasználó sikeresen regisztrálva!";

                // Az új felhasználó azonnali bejelentkezése
                $partner_id = $dbconn->lastInsertId();  // Az új felhasználó partner_id-ja
                $_SESSION["user"] = array(
                    "partner_id" => $partner_id,
                    "felhasznalonev" => $username
                );

                // Ha a felhasználó szeretné, hogy bejelentkezve maradjon
                if (isset($_POST["isNewUser"])) {
                    setcookie("userId", $partner_id, time() + 3 * 60);  // Cookie beállítása
                }

                // Átirányítás a bejelentkezett oldalra
                header("Location: Partner2.php");
                exit(); // Ne felejtsd el az exit-t!
            }
        } catch (Exception $e) {
            $error = "Bejelentkezési hiba: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Bejelentkezés</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="card">
            <h1>Partner Bejelentkezés</h1>
            <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
            <?php if (!empty($msg)) echo "<p style='color: green;'>$msg</p>"; ?>
            <form action="" method="post">
                <input type="text" name="username" placeholder="Felhasználónév" autocomplete="username" >
                <br><br>
                <input type="password" name="password" id="password" autocomplete="current-password" placeholder="Jelszó" >
                <br><br>
                <input type="checkbox" name="isNewUser"> Mentés
                <br><br>
                <button type="submit">Bejelentkezés</button>
            </form>
        </div>
    </div>
</body>
</html>

