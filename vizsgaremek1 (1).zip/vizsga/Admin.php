
<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: Rendszergazda.php");
    exit();
}

require_once("dbconnect.php");
$action = $_POST['action'] ?? null; 
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];



    if ($action === 'elfogad' && isset($_POST['rendeles'])) {
        $rendeles = json_decode($_POST['rendeles'], true);
    
        if (!is_array($rendeles)) {
            echo json_encode(["success" => false, "message" => "Hiba: Hibás rendelési formátum!"]);
            exit();
        }
    
        $alapanyagok = [
            'fem' =>  0,
            'femcso' =>  0,
            'femrud' =>  0,
            'vas' =>  0,
            'vasrud' =>  0,
            'vascso' =>  0
        ];
    
        foreach ($rendeles as $termek) {
            preg_match('/^([^\(]+) \((kg|db|m)\): (\d+)$/', $termek, $matches);
            if ($matches) {
                $termekNeve = trim($matches[1]);
                $mennyiseg = intval($matches[3]);
    
                switch ($termekNeve) {
                    case 'Fém': $alapanyagok['fem'] = $mennyiseg; break;
                    case 'Fémcső': $alapanyagok['femcso'] = $mennyiseg; break;
                    case 'Fémrúd': $alapanyagok['femrud'] = $mennyiseg; break;
                    case 'Vas': $alapanyagok['vas'] = $mennyiseg; break;
                    case 'Vasrúd': $alapanyagok['vasrud'] = $mennyiseg; break;
                    case 'Vascső': $alapanyagok['vascso'] = $mennyiseg; break;
                }
            }
        }
    
        try {
            $sql = "INSERT INTO bolt (fem, femcso, femrud, vas, vasrud, vascso) 
                    VALUES (:fem, :femcso, :femrud, :vas, :vasrud, :vascso)";
            $stmt = $dbconn->prepare($sql);
            $stmt->execute([
                'fem' => $alapanyagok['fem'],
                'femcso' => $alapanyagok['femcso'],
                'femrud' => $alapanyagok['femrud'],
                'vas' => $alapanyagok['vas'],
                'vasrud' => $alapanyagok['vasrud'],
                'vascso' => $alapanyagok['vascso']
            ]);
            $id = $dbconn->lastInsertId();
            if ($id) {
                echo json_encode(["success" => true, "message" => "Rendelés sikeresen rögzítve!", "id" => $id]);
            } else {
                echo json_encode(["success" => false, "message" => "Hiba: Az adatbázis nem adott vissza érvényes azonosítót."]);
            }
    
        } catch (PDOException $e) {
            echo "Hiba: " . $e->getMessage();
        }
        exit();
    }

       
    if ($_POST['action'] === 'torol' && isset($_POST['id'])) {
        $id = intval($_POST['id']);
        try {
            $stmt_delete = $dbconn->prepare("DELETE FROM bolt WHERE id = :id");
            $stmt_delete->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt_delete->execute();
    
            if ($stmt_delete->rowCount() > 0) {
                echo json_encode(["status" => true, "message" => "Rendelés sikeresen törölve."]);
            } else {
                echo json_encode(["status" => false, "message" => "Nem található ilyen ID."]);
            }
        } catch (PDOException $e) {
            echo json_encode(["status" => false, "message" => "Hiba: " . $e->getMessage()]);
        }
    
        exit;
    }

    //-----------------
    
    if ($action === 'elfogadpartner' && isset($_POST['index'])) {
        $partnerInput = json_decode($_POST['index'], true);
    
        if (!is_array($partnerInput)) {
            echo json_encode(["success" => false, "message" => "Hiba: Hibás rendelési formátum!"]);
            exit();
        }
    
        if ($partnerInput === null) {
            echo json_encode(["success" => false, "message" => "Hiba: Érvénytelen JSON adat."]);
            exit();
        }
    
        // Partner adatok előkészítése
        $partnerAdatok = [
            'cegnev' => $partnerInput['info1'] ?? '',
            'ceghely' => $partnerInput['info2'] ?? '',
            'kapcsolattarto_nev' => $partnerInput['info3'] ?? '',
            'kapcsolattarto_elerhetoseg' => $partnerInput['info4'] ?? '',
            'ceg_adoszam' => $partnerInput['info5'] ?? '',
            'cegjegyzekszam' => $partnerInput['info6'] ?? '',
            'tevekenysegi_kor' => $partnerInput['info7'] ?? '',
            'szamla_adat' => $partnerInput['info8'] ?? '',
            'tarsasagi_szam' => $partnerInput['info9'] ?? '',
            'fizetesi_feltetelek' => $partnerInput['info10'] ?? ''
        ];
    
        // Adatok mentése az adatbázisba
        try {
            $sql = "INSERT INTO partneradatok (cegnev, ceghely, kapcsolattarto_nev, kapcsolattarto_elerhetoseg, ceg_adoszam, cegjegyzekszam, tevekenysegi_kor, szamla_adat, tarsasagi_szam, fizetesi_feltetelek) 
                    VALUES (:cegnev, :ceghely, :kapcsolattarto_nev, :kapcsolattarto_elerhetoseg, :ceg_adoszam, :cegjegyzekszam, :tevekenysegi_kor, :szamla_adat, :tarsasagi_szam, :fizetesi_feltetelek)";
    
            $stmt = $dbconn->prepare($sql);
            $stmt->execute([
                'cegnev' => $partnerAdatok['cegnev'],
                'ceghely' => $partnerAdatok['ceghely'],
                'kapcsolattarto_nev' => $partnerAdatok['kapcsolattarto_nev'],
                'kapcsolattarto_elerhetoseg' => $partnerAdatok['kapcsolattarto_elerhetoseg'],
                'ceg_adoszam' => $partnerAdatok['ceg_adoszam'],
                'cegjegyzekszam' => $partnerAdatok['cegjegyzekszam'],
                'tevekenysegi_kor' => $partnerAdatok['tevekenysegi_kor'],
                'szamla_adat' => $partnerAdatok['szamla_adat'],
                'tarsasagi_szam' => $partnerAdatok['tarsasagi_szam'],
                'fizetesi_feltetelek' => $partnerAdatok['fizetesi_feltetelek']
            ]);
    
            $id = $dbconn->lastInsertId();
            echo json_encode(["success" => true, "message" => "Partner adatai sikeresen elfogadva! ID: " . $id]);
        } catch (PDOException $e) {
            echo json_encode(["success" => false, "message" => "Hiba: " . $e->getMessage()]);
        }
        exit();
    }
    

    if ($_POST['action'] === 'torolpartner' && isset($_POST['id'])) {
        $id = intval($_POST['id']);
        try {
            $stmt = $dbconn->prepare("DELETE FROM partneradatok WHERE id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
    
            if ($stmt->rowCount() > 0) {
                echo json_encode(["status" => "success", "message" => "Partner sikeresen törölve."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Nem található ilyen ID."]);
            }
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => "Hiba: " . $e->getMessage()]);
        }
    
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Felület</title>
    <link rel="stylesheet" href="Admin.css">

    <script defer>
    //Űrlap elküldése a partner oldalra
    document.addEventListener("DOMContentLoaded", function () {
    const partnerekDiv = document.getElementById("partnerekDiv");
    const partnerek = JSON.parse(localStorage.getItem("partnerek")) || [];
    
    partnerek.forEach((partner, index) => {
        let button = document.createElement("button");
        button.textContent = `Partner #${index + 1}`;
        button.onclick = function () {
            showPartnerData(partner, index);
        };
        partnerekDiv.appendChild(button);
    });
});
        function showPartnerData(partner, index) {

            let partnerInfo = `
            Cég neve: ${partner.info1}\n 
            Cég székhelye: ${partner.info2}\n
            Kapcsolattartó neve és beosztása: ${partner.info3}\n
            Kapcsolattartó elérhetősége (telefon, e-mail): ${partner.info4}\n
            Cég adószáma: ${partner.info5}\n
            Cégjegyzékszám: ${partner.info6}\n    
            Tevékenységi kör: ${partner.info7}\n
            Számlázási adatok: ${partner.info8}\n
            Társadalombiztosítási szám: ${partner.info9}\n
            Fizetési feltételek: ${partner.info10}\n
             `;
            
            document.getElementById("partnerDetails").innerText = partnerInfo.replace(/\n/g, "\n");
            document.getElementById("partnerModal").style.display = "block";
            //törlés gomb
            document.getElementById("torles").onclick = function() {
            torolPartner(index); 
            };
            
            document.getElementById("elfogadas").onclick = function() {
                elfogadPartner(index);
            };
        }

//-------------------------------        
//Partner  elfogadása
function elfogadPartner(index) {
    let tartalomElem = document.getElementById("tartalom");
    let urlapDivElem = document.getElementById("urlapDiv");

    if (tartalomElem) tartalomElem.style.display = "block";
    if (urlapDivElem) urlapDivElem.style.display = "none";

    let partnerek = JSON.parse(localStorage.getItem("partnerek")) || [];
    console.log("LocalStorage-ban lévő partnerek:", partnerek);

    if (index < 0 || index >= partnerek.length) {
        console.error("Hiba: A kiválasztott partner index kívül esik a tömb határain!");
        alert("Hiba: Érvénytelen partner adat!");
        return;
    }

    let selectedPartner = partnerek[index];
    console.log("Kiválasztott partner adatai:", selectedPartner);

    fetch("admin.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            action: "elfogadpartner",
            index: JSON.stringify(selectedPartner)
        })
    })
    .then(response => response.text())
    .then(text => {
        console.log("Szerver válasza:", text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error("Nem sikerült JSON-t dekódolni:", e);
            alert("Hiba történt az elfogadás során.");
            return;
        }

        if (data.success && data.message.includes("ID:")) {
            const dbId = parseInt(data.message.split("ID:")[1].trim());
            console.log("Kapott dbId:", dbId);
            selectedPartner.dbId = dbId;
            partnerek[index] = selectedPartner;


            localStorage.setItem("partnerek", JSON.stringify(partnerek));
            alert("Partner sikeresen elfogadva!");
        } else {
            alert("Hiba: " + data.message);
        }
    })
    .catch(error => {
        console.error("Fetch hiba:", error);
        alert("Hiba történt a kérés feldolgozása közben!");
    });

    localStorage.setItem("alapanyagok", JSON.stringify([
        { id: 1, nev: "Fém", egyseg: "kg" },
        { id: 2, nev: "Fémcső", egyseg: "db" },
        { id: 3, nev: "Fémrúd", egyseg: "m" },
        { id: 4, nev: "Vas", egyseg: "kg" },
        { id: 5, nev: "Vasrúd", egyseg: "m" },
        { id: 6, nev: "Vascső", egyseg: "db" }
    ]));

    closeModal();
    localStorage.setItem("tartalomMegjelenik", "true");
}




//Partner törlése
function torolPartner(index) {
    let partnerek = JSON.parse(localStorage.getItem("partnerek")) || [];

    if (index < 0 || index >= partnerek.length) {
        alert("Hiba: Érvénytelen partner index.");
        return;
    }

    let partner = partnerek[index];

    if (!partner.dbId) {
        alert("Hiba: Nem található adatbázis ID ehhez a partnerhez!");
        return;
    }

    if (!confirm("Biztosan törölni szeretnéd a partnert?")) {
        return;
    }

    fetch("admin.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            action: "torolpartner",
            id: partner.dbId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            alert(data.message);
            partnerek.splice(index, 1); 
            localStorage.setItem("partnerek", JSON.stringify(partnerek)); 
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        alert("Hiba történt a törlési kérés során.");
    });
}

//-----------------------------
       
document.addEventListener("DOMContentLoaded", function () {
    //Rendelés elfogadáa
    function elfogadRendeles(index) {
    let rendelesek = JSON.parse(localStorage.getItem("rendelesek")) || [];

    if (index < 0 || index >= rendelesek.length) {
        console.error("Hiba: A kiválasztott rendelés index kívül esik a tömb határain!");
        alert("Hiba: Érvénytelen rendelés!");
        return;
    }

    let selectedRendeles = rendelesek[index];
    
    // Ha még nem objektum, alakítsuk át
    if (!selectedRendeles || !selectedRendeles.tetel) {
        selectedRendeles = {
            tetel: selectedRendeles
        };
    }

    console.log("Kiválasztott rendelés adatai:", selectedRendeles.tetel);

    fetch("admin.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            action: "elfogad",
            rendeles: JSON.stringify(selectedRendeles.tetel)
        })
    })
    .then(response => response.text())
    .then(text => {
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error("Nem sikerült JSON-t dekódolni:", e);
            alert("Hiba történt az elfogadás során.");
            return;
        }

        if (data.success && data.id) {
            const dbId = parseInt(data.id);
            console.log("Kapott dbId:", dbId);
            selectedRendeles.dbId = dbId;
            rendelesek[index] = selectedRendeles;
            localStorage.setItem("rendelesek", JSON.stringify(rendelesek));
            alert("Rendelés sikeresen elfogadva!");
        } else {
            alert("Hiba: " + data.message);
        }
    })
    .catch(error => {
        console.error("Fetch hiba:", error);
        alert("Hiba történt a rendelés elküldésekor.");
    });
}
// Rendelés törlése
function torolRendeles(index) {
    let rendelesek = JSON.parse(localStorage.getItem("rendelesek")) || [];
   

    if (index < 0 || index >= rendelesek.length) {
        alert("Hiba: Érvénytelen rendelés index.");
        return;
    }

    let rendeles = rendelesek[index];

    if (!rendeles.dbId) {
        alert("Hiba: Nincs 'dbId' az adott rendelésnél!");
        console.log("Rendelés:", rendeles);
        return;
    }

    if (!confirm("Biztosan törölni szeretnéd a rendelést?")) {
        return;
    }
    rendelesek.splice(index, 1); 
    localStorage.setItem("rendelesek", JSON.stringify(rendelesek)); 
    megjelenitRendelesek();

    fetch("admin.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            action: "torol",
            id: rendeles.dbId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            alert(data.message);
            rendelesek.splice(index, 1);
            localStorage.setItem("rendelesek", JSON.stringify(rendelesek)); 
            location.reload();
        } else {
            alert(data.message);
        }
    })
    .catch(error => {
        alert("Hiba történt a törlés során.");
        console.error("Hiba:", error);
    });
}




//rendelés megjelenitése
function megjelenitRendelesek() {
    let rendelesDiv = document.getElementById("rendelesek");
    let rendelesek = JSON.parse(localStorage.getItem("rendelesek")) || [];

    if (rendelesek.length === 0) {
        rendelesDiv.innerHTML += "<p>Még nincsenek rendelések.</p>";
        return;
    } else {
        rendelesek.forEach((rendeles, index) => {
            let orderDiv = document.createElement("div");
            orderDiv.classList.add("rendeles");

            let orderTitle = document.createElement("h3");
            orderTitle.textContent = `Rendelés #${index + 1}`;
            orderDiv.appendChild(orderTitle);

            let orderContent = document.createElement("p");
            orderContent.textContent = Object.values(rendeles).join(" - ");
            orderDiv.appendChild(orderContent);
            
            let acceptButton = document.createElement("button");
            acceptButton.textContent = "Elfogadás";
            acceptButton.onclick = function () {
                elfogadRendeles(index); 
            };
            orderDiv.appendChild(acceptButton);

            let deleteButton = document.createElement("button");
            deleteButton.textContent = "Törlés";
            deleteButton.onclick = function () {
                torolRendeles(index); 
            };

            orderDiv.appendChild(deleteButton);
            rendelesDiv.appendChild(orderDiv);
        });
    }
}

document.addEventListener("DOMContentLoaded", megjelenitRendelesek());
});


//modal ablak
function closeModal() {
    document.getElementById("partnerModal").style.display = "none";
}

//gomb
function kuldes(){
    localStorage.setItem("urlapErkezett", "true");
    alert("Az űrlap elküldése sikeres!");
} 


    </script>
</head>
<body> 
    <div class="card">
        <h1>Üdvözöljük, Rendszergazda!</h1>
    </div>
    <div class="urlap" id="urlapDiv">
        <h1>Üdvözöljük, Partner!</h1>
        <form >
            <label for="info1">Cég neve:</label>
            <input type="text" id="info1" name="info1"  readonly>

            <label for="info2">Cég székhelye:</label>
            <input type="text" id="info2" name="info2" readonly>

            <label for="info3">Kapcsolattartó neve és beosztása:</label>
            <input type="text" id="info3" name="info3" readonly>

            <label for="info4">Kapcsolattartó elérhetősége (telefon, e-mail):</label>
            <input type="text" id="info4" name="info4" readonly>

            <label for="info5">Cég adószáma:</label>
            <input type="text" id="info5" name="info5" readonly>

            <label for="info6">Cégjegyzékszám:</label>
            <input type="text" id="info6" name="info6" readonly>

            <label for="info7">Tevékenységi kör:</label>
            <input type="text" id="info7" name="info7" readonly>

            <label for="info8">Számlázási adatok:</label>
            <input type="text" id="info8" name="info8" readonly>

            <label for="info9">Társadalombiztosítási szám:</label>
            <input type="text" id="info9" name="info9" readonly>

            <label for="info10">Fizetési feltételek:</label>
            <input type="text" id="info10" name="info10" readonly>

            <button type="button" onclick="kuldes()">Küldés</button>
        </form>
    </div>
    <div class="anyagok">
        <h2>Rendelt alapanyagok</h2>
        <div id="rendelesek">
        </div>
    </div>
    <div class="partnerek" id="partnerekDiv">
        <h3>Partnerek</h3>
    </div>
    <div id="partnerModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Partner adatai</h2>
            <p id="partnerDetails"></p>
        <button id="torles" onclick="torolPartner()">Törlés</button>
        <button id="elfogadas" onclick="elfogadPartner()">Elfogadás</button>
        </div>
    </div>
</form>
</body>
</html>
