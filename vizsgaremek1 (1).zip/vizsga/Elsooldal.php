<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal</title>
    <link rel="stylesheet" href="style.css">
</head>
<body> 
    <div class="container">
        <div class="card">
            <h1>Kérem válasszon, melyikkel szeretné folytatni:</h1>
            <div class="options">
                <a href="Partner.php">Partner</a>
                <a href="Rendszergazda.php">Rendszergazda</a>
                <a href="Vasarlo.php">Vásárló</a>
            </div>
        </div>
    </div>
</body>
</html>