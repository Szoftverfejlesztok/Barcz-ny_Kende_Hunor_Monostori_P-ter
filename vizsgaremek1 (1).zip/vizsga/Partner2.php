<?php
session_start();
if (!isset($_SESSION["user"])) {
    // Ha a felhasználó nincs bejelentkezve, irányítsd át a bejelentkezés oldalra
    header("Location: Partner.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <div class="container" id="partnerContainer">
        <div class="urlap" id="urlapDiv" style="display: none;">
            <h1>Üdvözöljük, Partner!</h1>
            <form>
                <label for="info1">Cég neve:</label>
                <input type="text" id="info1" name="info1" required>

                <label for="info2">Cég székhelye:</label>
                <input type="text" id="info2" name="info2" required>

                <label for="info3">Kapcsolattartó neve és beosztása:</label>
                <input type="text" id="info3" name="info3" required>

                <label for="info4">Kapcsolattartó elérhetősége (telefon, e-mail):</label>
                <input type="text" id="info4" name="info4" required>

                <label for="info5">Cég adószáma:</label>
                <input type="text" id="info5" name="info5" required>

                <label for="info6">Cégjegyzékszám:</label>
                <input type="text" id="info6" name="info6" required>

                <label for="info7">Tevékenységi kör:</label>
                <input type="text" id="info7" name="info7" required>

                <label for="info8">Számlázási adatok:</label>
                <input type="text" id="info8" name="info8" required>

                <label for="info9">Társadalombiztosítási szám:</label>
                <input type="text" id="info9" name="info9" required>

                <label for="info10">Fizetési feltételek:</label>
                <input type="text" id="info10" name="info10" required>

                <button type="button" onclick="visszakuld()">Visszaküldés</button>
            </form>
        </div>
        <div id="tartalom" class="tartalom" style="display: none;">
            <h1>Elérhető alapanyagok</h1>
        </div>
    </div>

    <script>
      
      window.addEventListener("DOMContentLoaded", function () {
        let urlapErkezett = localStorage.getItem("urlapErkezett");
        let tartalomMegjelenik = localStorage.getItem("tartalomMegjelenik");

        if (urlapErkezett === "true") {
            document.getElementById("urlapDiv").style.display = "block";
        
            localStorage.setItem("urlapErkezett", "false"); 
        }

        if (tartalomMegjelenik === "true") {
            document.getElementById("tartalom").style.display = "block";
            localStorage.setItem("tartalomMegjelenik", "false"); 
        }
    });

function visszakuld() {
        localStorage.setItem("urlapKitoltve", "false");
        localStorage.setItem("tartalomMegjelenik", "false");
        document.getElementById("tartalom").style.display = "none";
        let partnerData = {
            info1: document.getElementById("info1").value,
            info2: document.getElementById("info2").value,
            info3: document.getElementById("info3").value,
            info4: document.getElementById("info4").value,
            info5: document.getElementById("info5").value,
            info6: document.getElementById("info6").value,
            info7: document.getElementById("info7").value,
            info8: document.getElementById("info8").value,
            info9: document.getElementById("info9").value,
            info10: document.getElementById("info10").value
        };

        for (let key in partnerData) {
            if (partnerData[key] === "") {
                alert("Minden mezőt ki kell tölteni!");
                return; 
            }
        }
        let formData = new FormData();
    formData.append("partnerData", JSON.stringify(partnerData));

    fetch(window.location.href, {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            alert("Az űrlapot visszaküldtük és elmentettük az adatbázisba!");
            document.getElementById("urlapDiv").style.display = "none";
            window.location.href = "admin.php";
        } else {
            alert("Hiba történt az adatbázisba mentéskor: " + data.message);
        }
    }).catch(error => console.error("Hálózati hiba:", error));

    
        let partnerek = JSON.parse(localStorage.getItem("partnerek")) || [];
        partnerek.push(partnerData);
        localStorage.setItem("partnerek", JSON.stringify(partnerek));
        
        alert("Az űrlapot visszaküldtük az adminnak!");
        document.getElementById("urlapDiv").style.display = "none";
        window.location.href = "admin.php";
    }  
        document.addEventListener("DOMContentLoaded", function () {
            const alapanyagok = [
                { id: 1, nev: "Fém", egyseg: "kg" },
                { id: 2, nev: "Fémcső", egyseg: "db" },
                { id: 3, nev: "Fémrúd", egyseg: "m" },
                { id: 4, nev: "Vas", egyseg: "kg" },
                { id: 5, nev: "Vasrúd", egyseg: "m" },
                { id: 6, nev: "Vascső", egyseg: "db" }
            ];
            for (let key in alapanyagok) {
                if (alapanyagok[key] === "") {
                    alert("Minden mezőt ki kell tölteni!");
                    return;
                }
            }
            
            const tartalomDiv = document.getElementById("tartalom");
            const form = document.createElement("form");
            form.id = "orderForm";

            alapanyagok.forEach(alapanyag => {
                const listItem = document.createElement("div");
                listItem.classList.add("anyag-container");
                listItem.innerHTML = `
                    <label for="anyag-${alapanyag.id}">${alapanyag.nev} (${alapanyag.egyseg}):</label>
                    <select id="anyag-${alapanyag.id}" class="dropdown" data-id="${alapanyag.id}">
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>

                    </select>
                `;
                form.appendChild(listItem);
            });

            const buttonContainer = document.createElement("div");
            buttonContainer.classList.add("button-container");

            const button = document.createElement("button");
            button.type = "button";
            button.textContent = "Megrendelés";
            button.id = "submitOrder";
            buttonContainer.appendChild(button);
            form.appendChild(buttonContainer);

            tartalomDiv.appendChild(form);

            button.addEventListener("click", function () {

                let selectedItems = [];
                let selects = document.querySelectorAll(".dropdown");

                selects.forEach(select => {
                    let amount = select.value;
                    let materialName = select.previousElementSibling.textContent;

                    if (amount > 0) {
                        selectedItems.push(`${materialName} ${amount}`);
                    }
                });

                if (selectedItems.length === 0) {
                    alert("Kérlek válassz ki legalább egy alapanyagot!");
                } else {
                    let orders = JSON.parse(localStorage.getItem("rendelesek")) || [];
                    orders.push(selectedItems);
                    localStorage.setItem("rendelesek", JSON.stringify(orders));  
                    alert("Rendelés rögzítve! Továbbítás az admin oldalra...");
                    window.location.href = "admin.php";
                
                }
            });
        });
    </script>
</body>
</html>
