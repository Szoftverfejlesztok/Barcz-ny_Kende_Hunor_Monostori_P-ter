-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Ápr 08. 21:17
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `vizsgaremek1`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `felhasznalonev` varchar(50) NOT NULL,
  `jelszo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `admin`
--

INSERT INTO `admin` (`id`, `felhasznalonev`, `jelszo`) VALUES
(1, 'asd', 'asd'),
(2, 'qwe', 'qwe'),
(3, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `bolt`
--

CREATE TABLE `bolt` (
  `id` int(11) NOT NULL,
  `bolt_id` int(11) DEFAULT NULL,
  `fem` int(11) NOT NULL,
  `femcso` int(11) NOT NULL,
  `femrud` int(11) NOT NULL,
  `vas` int(11) NOT NULL,
  `vasrud` int(11) NOT NULL,
  `vascso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `bolt`
--

INSERT INTO `bolt` (`id`, `bolt_id`, `fem`, `femcso`, `femrud`, `vas`, `vasrud`, `vascso`) VALUES
(1, NULL, 2, 1, 1, 2, 1, 1),
(2, NULL, 3, 2, 2, 2, 2, 2),
(3, NULL, 3, 2, 2, 2, 2, 2),
(4, NULL, 3, 2, 2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `kezdooldal`
--

CREATE TABLE `kezdooldal` (
  `kezdooldal_id` int(11) NOT NULL,
  `adminoldal` int(11) NOT NULL,
  `partneroldal` int(11) NOT NULL,
  `vasarlooldal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `partner`
--

CREATE TABLE `partner` (
  `id` int(11) NOT NULL,
  `partner_id` int(11) DEFAULT NULL,
  `felhasznalonev` varchar(50) NOT NULL,
  `jelszo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `partner`
--

INSERT INTO `partner` (`id`, `partner_id`, `felhasznalonev`, `jelszo`) VALUES
(1, 1, 'asd', '$2y$10$uXirqI1F74w86OFEvK8RA.mnPBKO3B7Q6DK61Fyr7ur3AfOj5qGpG'),
(2, 2, 'qwe', '$2y$10$DQ72sDjEDET4SL5whr7GaufCB7s9jX3iaeQfc7Kvt6hMnyywd1McK'),
(3, NULL, 'q', '$2y$10$73dtInhv09Df4544Ui0gGOHSNsu9cSbYqjsRhsP0sM/MBTfYr/55O'),
(4, NULL, 'a', '$2y$10$HDELIz0XWXDugC2YkwSIPOM0lPqG.Qyp17ostqI9XotN2QeiVFed2'),
(5, NULL, 'rtx', '$2y$10$IWgh/A9Oo6hCAQ3sefFB2uj2AmslTNy/grN4Y./ZB6KyLRdW8Qo5a'),
(6, NULL, 't', '$2y$10$BFh4RGvcN4G893A1ZhIIT.OgFkuxZrQ7zHW76E9C.7WNugd1OgwNG');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `partneradatok`
--

CREATE TABLE `partneradatok` (
  `id` int(11) NOT NULL,
  `partner_id` int(11) DEFAULT NULL,
  `cegnev` varchar(50) NOT NULL,
  `ceghely` varchar(50) NOT NULL,
  `kapcsolattarto_nev` varchar(50) NOT NULL,
  `kapcsolattarto_elerhetoseg` text NOT NULL,
  `ceg_adoszam` varchar(20) NOT NULL,
  `cegjegyzekszam` varchar(20) NOT NULL,
  `tevekenysegi_kor` varchar(50) NOT NULL,
  `szamla_adat` varchar(30) NOT NULL,
  `tarsasagi_szam` varchar(30) NOT NULL,
  `fizetesi_feltetelek` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `partneradatok`
--

INSERT INTO `partneradatok` (`id`, `partner_id`, `cegnev`, `ceghely`, `kapcsolattarto_nev`, `kapcsolattarto_elerhetoseg`, `ceg_adoszam`, `cegjegyzekszam`, `tevekenysegi_kor`, `szamla_adat`, `tarsasagi_szam`, `fizetesi_feltetelek`) VALUES
(2, NULL, 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd', 'asd');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `termekek`
--

CREATE TABLE `termekek` (
  `termek_id` int(11) NOT NULL,
  `nev` varchar(20) NOT NULL,
  `ar` int(11) NOT NULL,
  `mennyiseg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `termekek`
--

INSERT INTO `termekek` (`termek_id`, `nev`, `ar`, `mennyiseg`) VALUES
(1, 'fém', 5000, 100),
(2, 'fémcső', 6000, 100),
(3, 'fémrúd', 6000, 100),
(4, 'vas', 5000, 100),
(5, 'vasrúd', 6000, 100),
(6, 'vascső', 6000, 100);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `vasarlo`
--

CREATE TABLE `vasarlo` (
  `id` int(11) NOT NULL,
  `vasarlo_id` int(11) DEFAULT NULL,
  `felhasznalonev` varchar(50) NOT NULL,
  `jelszo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `vasarlo`
--

INSERT INTO `vasarlo` (`id`, `vasarlo_id`, `felhasznalonev`, `jelszo`) VALUES
(1, NULL, 'asd', '$2y$10$DH5/4qXTB0xlETVD9HCog.FGn8s2jGFI.ScaWr6pSHxOIFWwqari2'),
(2, NULL, 'qwe', '$2y$10$/gi7n3R6lM9Kmt2RB6i74.HS1vejpkW5SvwmT2cvscgmk8O6wGL8i');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `id` (`id`);

--
-- A tábla indexei `bolt`
--
ALTER TABLE `bolt`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bolt_id` (`bolt_id`);

--
-- A tábla indexei `kezdooldal`
--
ALTER TABLE `kezdooldal`
  ADD PRIMARY KEY (`kezdooldal_id`),
  ADD KEY `adminoldal` (`adminoldal`),
  ADD KEY `partneroldal` (`partneroldal`),
  ADD KEY `vasarlooldal` (`vasarlooldal`);

--
-- A tábla indexei `partner`
--
ALTER TABLE `partner`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `partner_id` (`partner_id`);

--
-- A tábla indexei `partneradatok`
--
ALTER TABLE `partneradatok`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `partner_id` (`partner_id`);

--
-- A tábla indexei `termekek`
--
ALTER TABLE `termekek`
  ADD PRIMARY KEY (`termek_id`);

--
-- A tábla indexei `vasarlo`
--
ALTER TABLE `vasarlo`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vasarlo_id` (`vasarlo_id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT a táblához `bolt`
--
ALTER TABLE `bolt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT a táblához `kezdooldal`
--
ALTER TABLE `kezdooldal`
  MODIFY `kezdooldal_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `partner`
--
ALTER TABLE `partner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `partneradatok`
--
ALTER TABLE `partneradatok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `termekek`
--
ALTER TABLE `termekek`
  MODIFY `termek_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT a táblához `vasarlo`
--
ALTER TABLE `vasarlo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`id`) REFERENCES `termekek` (`termek_id`);

--
-- Megkötések a táblához `kezdooldal`
--
ALTER TABLE `kezdooldal`
  ADD CONSTRAINT `kezdooldal_ibfk_1` FOREIGN KEY (`adminoldal`) REFERENCES `admin` (`id`),
  ADD CONSTRAINT `kezdooldal_ibfk_3` FOREIGN KEY (`vasarlooldal`) REFERENCES `vasarlo` (`id`),
  ADD CONSTRAINT `kezdooldal_ibfk_4` FOREIGN KEY (`partneroldal`) REFERENCES `partner` (`id`);

--
-- Megkötések a táblához `partneradatok`
--
ALTER TABLE `partneradatok`
  ADD CONSTRAINT `partneradatok_ibfk_1` FOREIGN KEY (`partner_id`) REFERENCES `partner` (`partner_id`);

--
-- Megkötések a táblához `vasarlo`
--
ALTER TABLE `vasarlo`
  ADD CONSTRAINT `vasarlo_ibfk_1` FOREIGN KEY (`vasarlo_id`) REFERENCES `bolt` (`bolt_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
